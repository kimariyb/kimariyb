# Monolisa Font

This a freemium version of the font [Monolisa](https://www.monolisa.dev/), Has every type of font (Regular, Italic, Bold) and so on...

It consists of the Given Fonts below:

- Monolisa Black
- Monolisa Black Italic
- Monolisa Bold
- Monolisa Bold Italic
- Monolisa Extralight
- Monolisa Extralight Italic
- Monolisa Light
- Monolias Light Italic
- Monolisa Medium
- Monolisa Medium Italic
- Monolisa Regular
- Monolisa Regular Italic
- Monolisa Thin
- Monolisa Thin Italic

...Thank me later :)